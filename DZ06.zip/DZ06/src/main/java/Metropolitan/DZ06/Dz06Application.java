package Metropolitan.DZ06;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class Dz06Application {

	public static void main(String[] args) {
		
		SpringApplication.run(Dz06Application.class, args);

	}

}
