package Metropolitan.DZ06.student;

public enum AppUserRole {
USER,
ADMIN
	
}
